import { createRequire } from "module"; // Bring in the ability to create the 'require' method
const require = createRequire(import.meta.url); // construct the require method
const my_json_file = require("path/to/json/your-json-file.json") // use the require method

import Info from './models/info.js'
import infoData from '../data.json'
import Comment from './models/comment.js'
import commentData from '../comment.json'

const dataInit = async () => {
    const checkData = await Info.find()
    
    if (checkData.length !== 19) {
      console.log("Total restaurants are not equal to default ", checkData.length)
      await Info.deleteMany({})
      await Info.insertMany(infoData)
    }
    else{
      console.log("The number of restaurants is correct", checkData.length)
    }
    const checkComment = await Comment.find()
    if (checkComment.length !== 51) {
      console.log("Total comments are not equal to default ", checkComment.length)
      await Comment.deleteMany({})
      await Comment.insertMany(commentData)
    }
    else{
      console.log("The number of comments is correct", checkComment.length)
    }
}
  

export { dataInit }